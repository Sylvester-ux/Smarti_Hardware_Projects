#ifndef UTILS_H
#define UTILS_H

#include <Arduino.h>

// Small, self-contained helpers shared across modules.
//
// Kept header-only (every function is `inline`) so no Utils.cpp is
// needed - this file can be #included from multiple .cpp files
// without causing duplicate-symbol errors at link time.
namespace Utils
{
    // Converts a duration given in whole seconds (the unit used on
    // the wire by REQUEST_MAIN/REQUEST_SIDE, e.g. "REQUEST_MAIN,20")
    // into milliseconds (the unit TimerManager and TrafficLights
    // work in internally).
    //
    // The cast to unsigned long happens before the multiply, so a
    // large seconds value widens safely instead of wrapping the way
    // it would under 16-bit (uint16_t) arithmetic.
    inline unsigned long secondsToMillis(uint16_t seconds)
    {
        return (unsigned long)seconds * 1000UL;
    }

    // Inverse of secondsToMillis(), truncated toward zero. Meant for
    // human-readable status/logging output - not precise enough to
    // feed back into timing decisions.
    inline unsigned long millisToSeconds(unsigned long ms)
    {
        return ms / 1000UL;
    }

    // Clamps value into the closed range [minValue, maxValue].
    //
    // This exists instead of Arduino's built-in constrain() macro
    // on purpose: constrain(x, lo, hi) expands to something like
    // ((x) < (lo) ? (lo) : ((x) > (hi) ? (hi) : (x))) and evaluates
    // its first argument up to twice. That's harmless for a plain
    // variable, but silently wrong the moment someone passes an
    // expression with a side effect (constrain(x++, lo, hi)). A
    // normal function evaluates `value` exactly once, so it has no
    // such hazard.
    inline unsigned long clampULong(unsigned long value, unsigned long minValue, unsigned long maxValue)
    {
        if (value < minValue)
            return minValue;

        if (value > maxValue)
            return maxValue;

        return value;
    }
}

#endif
