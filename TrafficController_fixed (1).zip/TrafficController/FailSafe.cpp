#include "FailSafe.h"

void FailSafe::activate()
{
    active = true;
}

void FailSafe::clear()
{
    active = false;
}

bool FailSafe::isActive() const
{
    return active;
}
