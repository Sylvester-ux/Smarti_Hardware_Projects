#ifndef EMERGENCY_H
#define EMERGENCY_H

#include "Protocol.h"

// Tracks whether an emergency preemption is currently in effect and
// which direction (MAIN or SIDE) it applies to. This class only
// holds state - StateMachine is responsible for acting on it (e.g.
// truncating the opposing green, holding the target green longer).
class Emergency
{
public:
    void activate(CommandType direction);

    void clear();

    bool isActive() const;

    CommandType getTarget() const;

private:
    bool active = false;

    CommandType target = CommandType::NONE;
};

#endif
