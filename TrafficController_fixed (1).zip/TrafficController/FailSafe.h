#ifndef FAILSAFE_H
#define FAILSAFE_H

// Tracks whether the controller is latched into fail-safe (all-red,
// no automatic transitions). Once active, only an explicit RESET
// command clears it - this is intentional, fail-safe should never
// self-heal on a timer.
class FailSafe
{
public:
    void activate();

    void clear();

    bool isActive() const;

private:
    bool active = false;
};

#endif
