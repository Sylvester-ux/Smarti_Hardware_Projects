#include "Config.h"

#include "TrafficLights.h"
#include "TimerManager.h"
#include "SerialManager.h"
#include "CommandParser.h"
#include "StateMachine.h"

TrafficLights trafficLights;
TimerManager timer;
SerialManager serialManager;
CommandParser parser;

StateMachine stateMachine(trafficLights, timer);

void setup()
{
    trafficLights.begin();

    serialManager.begin(SERIAL_BAUD_RATE);

    stateMachine.begin();

    serialManager.sendMessage("Smart Traffic Controller Ready");
}

void loop()
{
    // Read serial data
    serialManager.update();

    // Process new command
    if (serialManager.available())
    {
        String msg = serialManager.getMessage();

        Command cmd = parser.parse(msg);

        if (cmd.valid)
        {
            stateMachine.handleCommand(cmd);

            if (cmd.type == CommandType::STATUS_REQUEST)
            {
                serialManager.sendMessage(stateMachine.getStatusString());
            }
            else
            {
                serialManager.sendMessage("ACK:" + msg);
            }
        }
        else
        {
            serialManager.sendMessage("NACK:" + msg);
        }

        serialManager.clearMessage();
    }

    // Update controller
    stateMachine.update();
}
