#ifndef LOGGER_H
#define LOGGER_H

#include <Arduino.h>

// Severity levels, ordered from most to least critical. The
// underlying values double as a threshold: a level is emitted only
// if it is <= the currently active threshold.
enum class LogLevel
{
    LOG_ERROR = 0,
    LOG_WARN  = 1,
    LOG_INFO  = 2,
    LOG_DEBUG = 3
};

// Minimal static logging utility.
//
// IMPORTANT: this shares the same physical Serial port as the
// command/response protocol (ACK:.../NACK:.../STATUS:...). Mixing
// unlabeled debug output into that stream is exactly the bug that
// made the original firmware's responses unparseable. To avoid
// repeating that:
//
//   1. Every log line is prefixed "LOG:" followed by its level, so
//      a reader can trivially skip logging output with a single
//      prefix check (e.g. `if line.startswith("LOG:"): continue`)
//      instead of trying to distinguish it from real responses.
//   2. The default threshold is LOG_WARN, so during normal
//      operation only genuinely abnormal events are logged, keeping
//      the serial stream close to one line per command.
//   3. Logger never runs on a timer and never logs per-loop-iteration
//      state - only call it from specific, discrete events (a state
//      change, a rejected command, etc.), never from inside update().
class Logger
{
public:
    static void error(const String& message);
    static void warn(const String& message);
    static void info(const String& message);
    static void debug(const String& message);

    // Raises or lowers the active threshold at runtime. Not persisted
    // across reboots - resets to LOG_WARN every time the board resets.
    static void setLevel(LogLevel level);

private:
    static LogLevel currentLevel;

    static void log(LogLevel level, const char* tag, const String& message);
};

#endif
