#include "Logger.h"

LogLevel Logger::currentLevel = LogLevel::LOG_WARN;

void Logger::setLevel(LogLevel level)
{
    currentLevel = level;
}

void Logger::log(LogLevel level, const char* tag, const String& message)
{
    if (level > currentLevel)
        return;

    String line = "LOG:";
    line += tag;
    line += ":";
    line += millis();
    line += ":";
    line += message;

    Serial.println(line);
}

void Logger::error(const String& message)
{
    log(LogLevel::LOG_ERROR, "ERROR", message);
}

void Logger::warn(const String& message)
{
    log(LogLevel::LOG_WARN, "WARN", message);
}

void Logger::info(const String& message)
{
    log(LogLevel::LOG_INFO, "INFO", message);
}

void Logger::debug(const String& message)
{
    log(LogLevel::LOG_DEBUG, "DEBUG", message);
}
