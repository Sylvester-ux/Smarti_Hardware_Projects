#include "Emergency.h"

void Emergency::activate(CommandType direction)
{
    active = true;
    target = direction;
}

void Emergency::clear()
{
    active = false;
    target = CommandType::NONE;
}

bool Emergency::isActive() const
{
    return active;
}

CommandType Emergency::getTarget() const
{
    return target;
}
