#ifndef SYSTEM_STATUS_H
#define SYSTEM_STATUS_H

#include <Arduino.h>
#include "Protocol.h"

/*************************************************
 *          SYSTEM MODES
 *************************************************/

enum class SystemMode
{
    NORMAL,

    EMERGENCY,

    FAILSAFE
};


/*************************************************
 *          SYSTEM STATUS STRUCTURE
 *************************************************/

struct SystemStatus
{
    TrafficState currentState = TrafficState::INIT;

    SystemMode mode = SystemMode::NORMAL;

    unsigned long remainingMs = 0;
};

#endif
