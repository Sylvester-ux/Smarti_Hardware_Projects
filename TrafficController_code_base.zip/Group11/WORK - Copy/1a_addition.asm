; ================================================
; 1A) 16-BIT ADDITION
; ================================================
org 100h

jmp start

; ------------------- Data ----------------------
num1    dw 0F0Ch
num2    dw 111Fh
result  dw 0
carry   db 0

msg1    db 13,10,"16-BIT ADDITION",13,10,"$"
msg2    db 13,10,"Sum    = $"
msg3    db 13,10,"Carry  = $"

; ------------------- Code -----------------------
start:
    mov ax, [num1]      ; move 1st data to accumulator
    mov bx, [num2]      ; move 2nd data to register
    add bx, ax          ; add the two data
    mov cl, 0            ; assume no carry
    jnc noCarry
    mov cl, 1            ; carry occurred
noCarry:
    mov [result], bx     ; store the result
    mov [carry], cl      ; store the carry

    ; ---- Print ----
    mov ah, 09h
    mov dx, msg1
    int 21h

    mov ah, 09h
    mov dx, msg2
    int 21h
    mov bx, [result]
    call PrintHexWord

    mov ah, 09h
    mov dx, msg3
    int 21h
    mov al, [carry]
    call PrintHexByte

    mov ax, 4C00h
    int 21h

; ================================================
; Print BX as a 4-digit hex word
; ================================================
PrintHexWord:
    push ax
    push bx
    push cx
    push dx

    mov dx, bx
    mov cx, 4
.nextDigit:
    push cx
    mov cl, 4
    rol dx, cl
    pop cx
    mov al, dl
    and al, 0Fh
    call PrintNibble
    loop .nextDigit

    pop dx
    pop cx
    pop bx
    pop ax
    ret

; ================================================
; Print AL as a 2-digit hex byte
; ================================================
PrintHexByte:
    push ax
    push cx

    mov ah, al
    mov cl, 4
    shr al, cl
    call PrintNibble

    mov al, ah
    and al, 0Fh
    call PrintNibble

    pop cx
    pop ax
    ret

; ================================================
; Print AL (0-0Fh) as one hex character
; ================================================
PrintNibble:
    cmp al, 9
    jbe digit
    add al, 7
digit:
    add al, '0'
    mov dl, al
    mov ah, 02h
    int 21h
    ret
