============================================================
MICROPROCESSORS LABORATORY
EXPERIMENT 1 - ARITHMETIC OPERATIONS

                                GROUP 11
                CE 2B - Computer Science and Engineering
============================================================

Course:
Microprocessors Laboratory

Class:
CE 2B

Department:
Computer Science and Engineering

Group:
Group 11

Processor:
Intel 8086

Assembler:
NASM

This project contains Intel 8086 Assembly Language programs
developed by Group 11 as part of the Microprocessors
Laboratory coursework.

The programs implement the arithmetic operations described
in Experiment 1 of the laboratory manual. Although the
laboratory manual provides implementations for the 8086
trainer kit using fixed memory addresses, these programs
have been implemented in NASM syntax as DOS console
applications while preserving the same algorithms and
expected functionality.

1a_addition.asm
Performs 16-bit unsigned addition.
Displays:
- Sum
- Carry Flag

1b_subtraction.asm
Performs 16-bit unsigned subtraction.
Displays:
- Result
- Borrow Flag

1c_multiplication.asm
Performs unsigned 16-bit multiplication using the
MUL instruction.
Displays the 32-bit product stored in DX.

1d_division.asm
Performs unsigned 32-bit by 16-bit division using the
DIV instruction.
Displays:
- Quotient
- Remainder

• Developed using Intel 8086 Assembly Language
• Written in NASM syntax
• Compatible with NASM assembler
• Uses DOS Interrupt 21H for console output
• Well-structured and commented source code
• Reusable hexadecimal output routines
• Modular and easy to understand

Assemble each source file using NASM.

Example:

```
nasm -f obj 1a_borrow.asm -o 1a.obj
```

Link the generated object file using a DOS-compatible
linker such as ALINK or an equivalent linker supported
by your development environment.

Addition:
Displays the computed sum and carry flag.

Subtraction:
Displays the computed result and borrow flag.

Multiplication:
Displays the 32-bit product contained in DX.

Division:
Displays the quotient and remainder after division.

These programs are based on the algorithms specified in
the Microprocessors Laboratory manual. The implementations
use NASM syntax and are intended to execute as DOS console
applications instead of directly on the 8086 trainer kit.

The objective of this project is to demonstrate the use of
8086 arithmetic instructions, register manipulation, flag
handling, and hexadecimal output formatting.