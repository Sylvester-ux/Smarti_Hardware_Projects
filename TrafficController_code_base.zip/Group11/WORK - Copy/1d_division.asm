; ================================================
; 1D) 16-BIT DIVISION (32-bit dividend / 16-bit divisor)
; ================================================
org 100h

jmp start

; ------------------- Data ----------------------
dividendLow  dw 2442h
dividendHigh dw 0000h
divisor      dw 0002h
quotient     dw 0
remainder    dw 0

msg1    db 13,10,"16-BIT DIVISION",13,10,"$"
msg2    db 13,10,"Quotient  = $"
msg3    db 13,10,"Remainder = $"

; ------------------- Code -----------------------
start:
    mov ax, [dividendLow]   ; AX = low word of dividend
    mov dx, [dividendHigh]  ; DX = high word of dividend
    mov bx, [divisor]       ; BX = divisor
    div bx                   ; AX = quotient, DX = remainder (DX:AX / BX)
    mov [quotient], ax       ; store quotient
    mov [remainder], dx      ; store remainder

    ; ---- Print ----
    mov ah, 09h
    mov dx, msg1
    int 21h

    mov ah, 09h
    mov dx, msg2
    int 21h
    mov bx, [quotient]
    call PrintHexWord

    mov ah, 09h
    mov dx, msg3
    int 21h
    mov bx, [remainder]
    call PrintHexWord

    mov ax, 4C00h
    int 21h

; ================================================
; Print BX as a 4-digit hex word
; ================================================
PrintHexWord:
    push ax
    push bx
    push cx
    push dx

    mov dx, bx
    mov cx, 4
.nextDigit:
    push cx
    mov cl, 4
    rol dx, cl
    pop cx
    mov al, dl
    and al, 0Fh
    call PrintNibble
    loop .nextDigit

    pop dx
    pop cx
    pop bx
    pop ax
    ret

; ================================================
; Print AL (0-0Fh) as one hex character
; ================================================
PrintNibble:
    cmp al, 9
    jbe digit
    add al, 7
digit:
    add al, '0'
    mov dl, al
    mov ah, 02h
    int 21h
    ret
