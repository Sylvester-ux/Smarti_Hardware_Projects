; ================================================
; 1C) 16-BIT MULTIPLICATION
; ================================================
org 100h

jmp start

; ------------------- Data ----------------------
data1     dw 1111h
data2     dw 1100h
resLow    dw 0        ; AX after MUL
resHigh   dw 0        ; DX after MUL (overflow)

msg1    db 13,10,"16-BIT MULTIPLICATION",13,10,"$"
msg2    db 13,10,"Product (DX:AX) = $"

; ------------------- Code -----------------------
start:
    mov ax, [data1]      ; move 1st value to accumulator
    mov bx, [data2]      ; move 2nd value to register
    mul bx                ; DX:AX = AX * BX
    mov [resLow], ax      ; store low word of result
    mov [resHigh], dx     ; store high word (overflow)

    ; ---- Print ----
    mov ah, 09h
    mov dx, msg1
    int 21h

    mov ah, 09h
    mov dx, msg2
    int 21h

    mov bx, [resHigh]     ; print high word first
    call PrintHexWord
    mov bx, [resLow]      ; then low word
    call PrintHexWord

    mov ax, 4C00h
    int 21h

; ================================================
; Print BX as a 4-digit hex word
; ================================================
PrintHexWord:
    push ax
    push bx
    push cx
    push dx

    mov dx, bx
    mov cx, 4
.nextDigit:
    push cx
    mov cl, 4
    rol dx, cl
    pop cx
    mov al, dl
    and al, 0Fh
    call PrintNibble
    loop .nextDigit

    pop dx
    pop cx
    pop bx
    pop ax
    ret

; ================================================
; Print AL (0-0Fh) as one hex character
; ================================================
PrintNibble:
    cmp al, 9
    jbe digit
    add al, 7
digit:
    add al, '0'
    mov dl, al
    mov ah, 02h
    int 21h
    ret
