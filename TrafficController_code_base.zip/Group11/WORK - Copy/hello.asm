org 0x100

section .text

    mov ah, 09h
    mov dx, msg
    int 21h

    mov ah, 4Ch
    int 21h


section .data
msg db 'Hello, Tango 6!$'