; =====================================================
; Question 1a - 16-bit Addition (with carry detection)
; Microprocessors Lab - 8086 Assembly
; Assembled with NASM, run as a DOS .COM binary in DOSBox
; =====================================================
org 0x100

section .text
start:
    ; --- Step 1: Initialize carry count to 0 ---
    mov byte [carry_count], 0

    ; --- Step 2: Get the two data values ---
    mov ax, [data1]
    mov bx, [data2]

    ; --- Step 3: Add the two data values ---
    add bx, ax                     ; BX = data1 + data2
    jnc no_carry                   ; jump if no carry generated
    inc byte [carry_count]         ; else increment carry count
no_carry:
    mov [result], bx               ; --- Step 4: Store the result ---

    ; --- Display everything ---
    mov dx, msg_intro
    mov ah, 09h
    int 21h

    mov dx, msg_d1
    mov ah, 09h
    int 21h
    mov bx, [data1]
    call print_hex16

    mov dx, msg_d2
    mov ah, 09h
    int 21h
    mov bx, [data2]
    call print_hex16

    mov dx, msg_result
    mov ah, 09h
    int 21h
    mov bx, [result]
    call print_hex16

    mov dx, msg_carry
    mov ah, 09h
    int 21h
    mov al, [carry_count]
    call print_hex8

    mov dx, msg_newline
    mov ah, 09h
    int 21h

    ; --- Step 5: Stop the process ---
    mov ax, 0x4C00
    int 21h


; =====================================================
; Subroutine: print_hex16
; Prints the 16-bit value in BX as 4 hex digits
; =====================================================
print_hex16:
    push cx
    mov cx, bx
    mov al, ch
    shr al, 4
    call print_nibble
    mov al, ch
    and al, 0x0F
    call print_nibble
    mov al, cl
    shr al, 4
    call print_nibble
    mov al, cl
    and al, 0x0F
    call print_nibble
    pop cx
    ret

; =====================================================
; Subroutine: print_hex8
; Prints the 8-bit value in AL as 2 hex digits
; =====================================================
print_hex8:
    push cx
    mov cl, al
    mov al, cl
    shr al, 4
    call print_nibble
    mov al, cl
    and al, 0x0F
    call print_nibble
    pop cx
    ret

; =====================================================
; Subroutine: print_nibble
; Prints the lowest 4 bits of AL as one hex character
; =====================================================
print_nibble:
    push dx
    cmp al, 9
    jle .digit
    add al, 'A' - 10
    jmp .print
.digit:
    add al, '0'
.print:
    mov dl, al
    mov ah, 02h
    int 21h
    pop dx
    ret


section .data
    data1       dw 0x0F0C      ; first 16-bit value (from lab manual example)
    data2       dw 0x111F      ; second 16-bit value

    result      dw 0
    carry_count db 0

    msg_intro   db '=== Q1a: 16-bit Addition ===', 13, 10, '$'
    msg_d1      db 'Data 1 : $'
    msg_d2      db 13, 10, 'Data 2 : $'
    msg_result  db 13, 10, 'Sum    : $'
    msg_carry   db 13, 10, 'Carry  : $'
    msg_newline db 13, 10, '$'