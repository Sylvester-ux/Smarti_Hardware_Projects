org 100h

jmp start

; ----------------------------------
; Data
; ----------------------------------

array db 49h,24h,64h,09h,32h
count equ 5

msg db 13,10,"Sorted Array (Ascending): $"

; ----------------------------------
; Code
; ----------------------------------

start:

; Bubble Sort

mov cx,count-1          ; Outer loop

outerLoop:

    mov si,array
    mov bx,cx

innerLoop:

    mov al,[si]
    mov dl,[si+1]

    cmp al,dl
    jbe noSwap

    ; Swap

    mov [si],dl
    mov [si+1],al

noSwap:

    inc si
    dec bx
    jnz innerLoop

loop outerLoop


; Print Message

mov ah,09h
mov dx,msg
int 21h

; Print Sorted Array

mov si,array
mov cx,count

printLoop:

    mov al,[si]
    call PrintHex

    mov dl,' '
    mov ah,02h
    int 21h

    inc si
    loop printLoop

; Exit

mov ax,4C00h
int 21h


; ----------------------------------
; Print AL as Hex
; ----------------------------------

PrintHex:
    push ax
    push cx

    mov ah, al          ; Save original byte

    mov cl, 4           ; 8086 requires variable shift count in CL
    shr al, cl          ; High nibble
    call PrintNibble

    mov al, ah          ; Restore original byte
    and al, 0Fh         ; Low nibble
    call PrintNibble

    pop cx
    pop ax
    ret

PrintNibble:
    cmp al, 9
    jbe digit

    add al, 7

digit:
    add al, '0'

    mov dl, al
    mov ah, 02h
    int 21h
    ret