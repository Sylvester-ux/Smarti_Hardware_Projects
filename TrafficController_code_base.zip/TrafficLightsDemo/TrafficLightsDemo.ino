// Traffic Light System
// Red LED -> Pin 12
// Yellow LED -> Pin 3
// Green LED -> Pin 4

const int redLED = 2;
const int yellowLED = 3;
const int greenLED = 4;

void setup() {
  // Set all LED pins as outputs
  pinMode(redLED, OUTPUT);
  pinMode(yellowLED, OUTPUT);
  pinMode(greenLED, OUTPUT);
}

void loop() {

  // GREEN LIGHT - Go
  digitalWrite(greenLED, HIGH);
  digitalWrite(yellowLED, LOW);
  digitalWrite(redLED, LOW);
  delay(10000);   // Green stays on for 5 seconds

  // YELLOW LIGHT - Slow down
  digitalWrite(greenLED, LOW);
  digitalWrite(yellowLED, HIGH);
  digitalWrite(redLED, LOW);
  delay(3000);   // Yellow stays on for 2 seconds

  // RED LIGHT - Stop
  digitalWrite(greenLED, LOW);
  digitalWrite(yellowLED, LOW);
  digitalWrite(redLED, HIGH);
  delay(6000);   // Red stays on for 5 seconds

  // RED + YELLOW (Optional: prepares to go)
  // digitalWrite(redLED, HIGH);
  // digitalWrite(yellowLED, HIGH);
  // digitalWrite(greenLED, LOW);
  // delay(1000);

  // The loop repeats automatically
}