#ifndef STATE_MACHINE_H
#define STATE_MACHINE_H

#include <Arduino.h>

#include "Protocol.h"
#include "TrafficLights.h"
#include "TimerManager.h"
#include "Emergency.h"
#include "FailSafe.h"
#include "SystemStatus.h"

class StateMachine
{
public:

    StateMachine(
        TrafficLights& lights,
        TimerManager& timer);

    void begin();

    void update();

    void handleCommand(const Command& command);

    TrafficState getCurrentState() const;

    // Builds a single-line status report, e.g.:
    // "STATUS:STATE=MAIN_GREEN,MODE=NORMAL,REMAINING=8342,PENDING_MAIN=NONE,PENDING_SIDE=15000"
    String getStatusString();

private:

    TrafficLights& trafficLights;

    TimerManager& timer;

    Emergency emergency;

    FailSafe failSafe;

    TrafficState currentState;

    SystemMode mode = SystemMode::NORMAL;

    // Pending direction requests are tracked separately (rather than
    // sharing one slot) so a REQUEST_SIDE can never silently discard
    // a still-waiting REQUEST_MAIN, and vice versa.
    bool hasPendingMain = false;
    unsigned long pendingMainDuration = 0;

    bool hasPendingSide = false;
    unsigned long pendingSideDuration = 0;

    unsigned long currentGreenDuration = 0;

    bool transitionFromMain = true;

    void enterMainGreen();

    void enterMainYellow();

    void enterAllRedToSide();

    void enterSideGreen();

    void enterSideYellow();

    void enterAllRedToMain();

    void enterFailSafe();

    void handleEmergencyRequest(CommandType direction);

    unsigned long clampGreenDuration(unsigned long requestedMs) const;

    const char* stateName(TrafficState state) const;

    const char* modeName(SystemMode m) const;
};

#endif
