#include "StateMachine.h"
#include "Config.h"

StateMachine::StateMachine(
    TrafficLights& lights,
    TimerManager& timer)
    :
    trafficLights(lights),
    timer(timer)
{

}

void StateMachine::begin()
{
    currentState = TrafficState::INIT;

    mode = SystemMode::NORMAL;

    hasPendingMain = false;
    hasPendingSide = false;

    emergency.clear();
    failSafe.clear();

    enterMainGreen();
}

unsigned long StateMachine::clampGreenDuration(unsigned long requestedMs) const
{
    if (requestedMs < MIN_GREEN_TIME)
        return MIN_GREEN_TIME;

    if (requestedMs > MAX_GREEN_TIME)
        return MAX_GREEN_TIME;

    return requestedMs;
}

void StateMachine::handleEmergencyRequest(CommandType direction)
{
    if (failSafe.isActive())
    {
        // Fail-safe takes priority over emergency preemption until
        // the system is explicitly reset.
        return;
    }

    emergency.activate(direction);
    mode = SystemMode::EMERGENCY;

    bool alreadyOnTarget =
        (direction == CommandType::REQUEST_MAIN && currentState == TrafficState::MAIN_GREEN) ||
        (direction == CommandType::REQUEST_SIDE && currentState == TrafficState::SIDE_GREEN);

    if (alreadyOnTarget)
    {
        // Already showing the requested direction - just hold it longer.
        timer.start(MAX_GREEN_TIME);
        return;
    }

    bool onOppositeGreen =
        (direction == CommandType::REQUEST_MAIN && currentState == TrafficState::SIDE_GREEN) ||
        (direction == CommandType::REQUEST_SIDE && currentState == TrafficState::MAIN_GREEN);

    if (onOppositeGreen)
    {
        // Cut the opposing green short, but never below the minimum
        // safe green time it has already been served.
        unsigned long elapsed = timer.elapsed();

        if (elapsed >= MIN_GREEN_TIME)
        {
            timer.start(1);
        }
        else
        {
            timer.start(MIN_GREEN_TIME - elapsed);
        }
    }

    // If we're mid-transition (yellow / all-red), those phases are
    // already short - let them run their course naturally.
}

void StateMachine::handleCommand(const Command& command)
{
    if (!command.valid)
        return;

    switch (command.type)
    {
        case CommandType::REQUEST_MAIN:
        {
            unsigned long requestedMs = (unsigned long)command.duration * 1000UL;
            pendingMainDuration = clampGreenDuration(requestedMs);
            hasPendingMain = true;
            break;
        }

        case CommandType::REQUEST_SIDE:
        {
            unsigned long requestedMs = (unsigned long)command.duration * 1000UL;
            pendingSideDuration = clampGreenDuration(requestedMs);
            hasPendingSide = true;
            break;
        }

        case CommandType::EMERGENCY_MAIN:
            handleEmergencyRequest(CommandType::REQUEST_MAIN);
            break;

        case CommandType::EMERGENCY_SIDE:
            handleEmergencyRequest(CommandType::REQUEST_SIDE);
            break;

        case CommandType::RESET:

            if (failSafe.isActive())
            {
                failSafe.clear();
                emergency.clear();
                mode = SystemMode::NORMAL;

                hasPendingMain = false;
                hasPendingSide = false;

                enterMainGreen();
            }
            else
            {
                emergency.clear();
                mode = SystemMode::NORMAL;
            }

            break;

        case CommandType::FAILSAFE:
            enterFailSafe();
            break;

        case CommandType::STATUS_REQUEST:
            // No state change - the caller reads current status directly.
            break;

        default:
            break;
    }
}

void StateMachine::enterFailSafe()
{
    currentState = TrafficState::FAILSAFE;

    mode = SystemMode::FAILSAFE;

    failSafe.activate();

    trafficLights.setAllRed();

    timer.stop();
}

void StateMachine::update()
{
    if (failSafe.isActive())
        return;

    if (!timer.expired())
        return;

    switch (currentState)
    {
        case TrafficState::MAIN_GREEN:

            transitionFromMain = true;

            enterMainYellow();

            break;

        case TrafficState::MAIN_YELLOW:

            enterAllRedToSide();

            break;

        case TrafficState::ALL_RED_TO_SIDE:

            enterSideGreen();

            break;

        case TrafficState::SIDE_GREEN:

            transitionFromMain = false;

            enterSideYellow();

            break;

        case TrafficState::SIDE_YELLOW:

            enterAllRedToMain();

            break;

        case TrafficState::ALL_RED_TO_MAIN:

            enterMainGreen();

            break;

        default:

            break;
    }
}

void StateMachine::enterMainGreen()
{
    currentState = TrafficState::MAIN_GREEN;

    trafficLights.setMainGreen();

    if (emergency.isActive() && emergency.getTarget() == CommandType::REQUEST_MAIN)
    {
        currentGreenDuration = MAX_GREEN_TIME;
    }
    else if (hasPendingMain)
    {
        currentGreenDuration = pendingMainDuration;

        hasPendingMain = false;
    }
    else
    {
        currentGreenDuration = MAIN_GREEN_TIME;
    }

    timer.start(currentGreenDuration);
}

void StateMachine::enterMainYellow()
{
    currentState = TrafficState::MAIN_YELLOW;

    trafficLights.setMainYellow();

    timer.start(YELLOW_TIME);
}

void StateMachine::enterAllRedToSide()
{
    currentState = TrafficState::ALL_RED_TO_SIDE;

    trafficLights.setAllRed();

    timer.start(ALL_RED_TIME);
}

void StateMachine::enterSideGreen()
{
    currentState = TrafficState::SIDE_GREEN;

    trafficLights.setSideGreen();

    if (emergency.isActive() && emergency.getTarget() == CommandType::REQUEST_SIDE)
    {
        currentGreenDuration = MAX_GREEN_TIME;
    }
    else if (hasPendingSide)
    {
        currentGreenDuration = pendingSideDuration;

        hasPendingSide = false;
    }
    else
    {
        currentGreenDuration = SIDE_GREEN_TIME;
    }

    timer.start(currentGreenDuration);
}

void StateMachine::enterSideYellow()
{
    currentState = TrafficState::SIDE_YELLOW;

    trafficLights.setSideYellow();

    timer.start(YELLOW_TIME);
}

void StateMachine::enterAllRedToMain()
{
    currentState = TrafficState::ALL_RED_TO_MAIN;

    trafficLights.setAllRed();

    timer.start(ALL_RED_TIME);
}

TrafficState StateMachine::getCurrentState() const
{
    return currentState;
}

const char* StateMachine::stateName(TrafficState state) const
{
    switch (state)
    {
        case TrafficState::INIT:            return "INIT";
        case TrafficState::MAIN_GREEN:      return "MAIN_GREEN";
        case TrafficState::MAIN_YELLOW:     return "MAIN_YELLOW";
        case TrafficState::ALL_RED_TO_SIDE: return "ALL_RED_TO_SIDE";
        case TrafficState::SIDE_GREEN:      return "SIDE_GREEN";
        case TrafficState::SIDE_YELLOW:     return "SIDE_YELLOW";
        case TrafficState::ALL_RED_TO_MAIN: return "ALL_RED_TO_MAIN";
        case TrafficState::FAILSAFE:        return "FAILSAFE";
        default:                            return "UNKNOWN";
    }
}

const char* StateMachine::modeName(SystemMode m) const
{
    switch (m)
    {
        case SystemMode::NORMAL:    return "NORMAL";
        case SystemMode::EMERGENCY: return "EMERGENCY";
        case SystemMode::FAILSAFE:  return "FAILSAFE";
        default:                     return "UNKNOWN";
    }
}

String StateMachine::getStatusString()
{
    SystemStatus status;
    status.currentState = currentState;
    status.mode = mode;
    status.remainingMs = timer.remaining();

    String result = "STATUS:STATE=";
    result += stateName(status.currentState);
    result += ",MODE=";
    result += modeName(status.mode);
    result += ",REMAINING=";
    result += status.remainingMs;
    result += ",PENDING_MAIN=";
    result += hasPendingMain ? String(pendingMainDuration) : String("NONE");
    result += ",PENDING_SIDE=";
    result += hasPendingSide ? String(pendingSideDuration) : String("NONE");

    return result;
}
