/*
 SMART TRAFFIC CONTROL SYSTEM - v2
 Embedded Systems Design
 Non-blocking (millis()) state machine, interrupt-driven emergency override,
 debounced pedestrian button, safe all-red clearance between phases.
*/

// Main signal
const int MR = 2;
const int MY = 3;
const int MG = 4;
// Side signal
const int SR = 5;
const int SY = 6;
const int SG = 7;
// Ultrasonic sensors
const int trigMain = 8;
const int echoMain = 9;
const int trigSide = 10;
const int echoSide = 11;
// Inputs
const int emergencyPin = 12;
const int pedestrianPin = 13;

// ---- Timing constants (ms) ----
const unsigned long GREEN_SHORT   = 5000;
const unsigned long GREEN_LONG    = 9000;
const unsigned long YELLOW_TIME   = 2000;
const unsigned long ALL_RED_TIME  = 500;   // clearance gap, both directions red
const unsigned long PED_WALK_TIME = 5000;
const unsigned long EMERGENCY_HOLD = 7000;
const unsigned long DEBOUNCE_MS   = 50;
const unsigned long US_TIMEOUT_US = 20000UL; // pulseIn timeout (~3.4m max range)

// ---- State machine ----
enum State {
  MAIN_GREEN,
  MAIN_YELLOW,
  CLEAR_TO_SIDE,
  SIDE_GREEN,
  SIDE_YELLOW,
  CLEAR_TO_MAIN,
  PEDESTRIAN,
  EMERGENCY
};

State currentState = MAIN_GREEN;
unsigned long stateStartTime = 0;
unsigned long currentGreenDuration = GREEN_SHORT;

// Emergency handled via ISR flag so it preempts instantly, even mid-delay-free loop
volatile bool emergencyFlag = false;

// Pedestrian debounce
bool pedRequestLatched = false;
int lastPedReading = HIGH;
unsigned long lastPedDebounceTime = 0;

// Remember which phase to resume after emergency/pedestrian interrupt
State stateBeforeInterrupt = MAIN_GREEN;

void emergencyISR() {
  emergencyFlag = true;
}

long getDistance(int trigPin, int echoPin) {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  long duration = pulseIn(echoPin, HIGH, US_TIMEOUT_US);
  if (duration == 0) return -1; // no echo / out of range, treat as "no car detected"
  return duration * 0.034 / 2;
}

// ---- Light helpers: always set the *incoming* red before dropping the outgoing green ----
void setMainGreen() {
  digitalWrite(SR, HIGH); digitalWrite(SY, LOW); digitalWrite(SG, LOW);
  digitalWrite(MR, LOW);  digitalWrite(MY, LOW); digitalWrite(MG, HIGH);
}
void setMainYellow() {
  digitalWrite(MG, LOW); digitalWrite(MY, HIGH); digitalWrite(MR, LOW);
}
void setSideGreen() {
  digitalWrite(MR, HIGH); digitalWrite(MY, LOW); digitalWrite(MG, LOW);
  digitalWrite(SR, LOW);  digitalWrite(SY, LOW); digitalWrite(SG, HIGH);
}
void setSideYellow() {
  digitalWrite(SG, LOW); digitalWrite(SY, HIGH); digitalWrite(SR, LOW);
}
void setAllRed() {
  digitalWrite(MG, LOW); digitalWrite(MY, LOW); digitalWrite(MR, HIGH);
  digitalWrite(SG, LOW); digitalWrite(SY, LOW); digitalWrite(SR, HIGH);
}

void enterState(State s) {
  currentState = s;
  stateStartTime = millis();

  switch (s) {
    case MAIN_GREEN: {
      long d = getDistance(trigMain, echoMain);
      currentGreenDuration = (d > 0 && d < 20) ? GREEN_LONG : GREEN_SHORT;
      Serial.print("Main Distance: "); Serial.println(d);
      setMainGreen();
      break;
    }
    case MAIN_YELLOW:
      setMainYellow();
      break;
    case CLEAR_TO_SIDE:
      setAllRed();
      break;
    case SIDE_GREEN: {
      long d = getDistance(trigSide, echoSide);
      currentGreenDuration = (d > 0 && d < 20) ? GREEN_LONG : GREEN_SHORT;
      Serial.print("Side Distance: "); Serial.println(d);
      setSideGreen();
      break;
    }
    case SIDE_YELLOW:
      setSideYellow();
      break;
    case CLEAR_TO_MAIN:
      setAllRed();
      break;
    case PEDESTRIAN:
      Serial.println("Pedestrian Crossing");
      setAllRed(); // both roads stopped, safe for a walk phase
      break;
    case EMERGENCY:
      Serial.println("Emergency Vehicle!");
      setAllRed(); // stop everyone first, unconditionally, before giving priority
      break;
  }
}

void setup() {
  pinMode(MR, OUTPUT); pinMode(MY, OUTPUT); pinMode(MG, OUTPUT);
  pinMode(SR, OUTPUT); pinMode(SY, OUTPUT); pinMode(SG, OUTPUT);
  pinMode(trigMain, OUTPUT); pinMode(echoMain, INPUT);
  pinMode(trigSide, OUTPUT); pinMode(echoSide, INPUT);
  pinMode(emergencyPin, INPUT_PULLUP);
  pinMode(pedestrianPin, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(emergencyPin), emergencyISR, FALLING);

  Serial.begin(9600);
  enterState(MAIN_GREEN);
}

void checkPedestrianButton() {
  int reading = digitalRead(pedestrianPin);
  if (reading != lastPedReading) {
    lastPedDebounceTime = millis();
  }
  if ((millis() - lastPedDebounceTime) > DEBOUNCE_MS) {
    if (reading == LOW) {
      pedRequestLatched = true; // service at next safe boundary, not mid-green
    }
  }
  lastPedReading = reading;
}

void loop() {
  checkPedestrianButton();

  // --- Emergency: highest priority, preempts any state instantly ---
  if (emergencyFlag && currentState != EMERGENCY) {
    stateBeforeInterrupt = currentState;
    enterState(EMERGENCY);
  }

  unsigned long elapsed = millis() - stateStartTime;

  switch (currentState) {

    case EMERGENCY:
      // Phase 1: universal all-red clearance (0-1000ms), then release Main only
      if (elapsed < 1000) {
        // already all-red from enterState()
      } else if (elapsed < 1000 + EMERGENCY_HOLD) {
        digitalWrite(MR, LOW); digitalWrite(MG, HIGH); // Main released for emergency lane
        digitalWrite(SR, HIGH); digitalWrite(SG, LOW);
      } else {
        emergencyFlag = false;
        digitalWrite(MG, LOW);
        enterState(CLEAR_TO_MAIN); // safe reset before resuming normal cycle
      }
      break;

    case PEDESTRIAN:
      if (elapsed >= PED_WALK_TIME) {
        pedRequestLatched = false;
        enterState(MAIN_GREEN);
      }
      break;

    case MAIN_GREEN:
      if (elapsed >= currentGreenDuration) enterState(MAIN_YELLOW);
      break;

    case MAIN_YELLOW:
      if (elapsed >= YELLOW_TIME) enterState(CLEAR_TO_SIDE);
      break;

    case CLEAR_TO_SIDE:
      if (elapsed >= ALL_RED_TIME) {
        if (pedRequestLatched) enterState(PEDESTRIAN);
        else enterState(SIDE_GREEN);
      }
      break;

    case SIDE_GREEN:
      if (elapsed >= currentGreenDuration) enterState(SIDE_YELLOW);
      break;

    case SIDE_YELLOW:
      if (elapsed >= YELLOW_TIME) enterState(CLEAR_TO_MAIN);
      break;

    case CLEAR_TO_MAIN:
      if (elapsed >= ALL_RED_TIME) {
        if (pedRequestLatched) enterState(PEDESTRIAN);
        else enterState(MAIN_GREEN);
      }
      break;
  }
}
